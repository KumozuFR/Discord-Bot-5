Features:

Customizable Messages
Advanced config
Create and customize your own pets
Hooks into Corebots Experience system
Hooks into Corebots coin system
View the top pets in your guild
Cross guild support
Coin rewards

Commands:

Adopt - Adopt a pet and take care of it
Name - Set the name of your pet
Feed - Feed your pet so it doesn't get hungry
Wash - Wash your pet so it doesn't get dirty
Play - Play with your pet so it's happy
Love - Show affection to your pet.
List - List all available pets that are up for adoption.
Info - View the statistics on a pet before adopting it.
Stats - View the stats of your pet.
Disown - Send your pet to another home by disowning it.
Top - View the top 10 pets in the server.